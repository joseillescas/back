package com.sistema.canchas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackSistemaCanchasSinteticasApplicationTests {

    @Test
    void contextLoads() {
    }

}
