package com.sistema.canchas.service;

import com.sistema.canchas.model.Ubicacion;

public interface UbicacionService extends GenericService<Ubicacion,Long>{
}
