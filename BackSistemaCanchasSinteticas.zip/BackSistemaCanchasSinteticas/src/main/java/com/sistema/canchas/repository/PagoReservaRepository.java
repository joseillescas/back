package com.sistema.canchas.repository;

import com.sistema.canchas.model.PagoReserva;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagoReservaRepository extends JpaRepository<PagoReserva,Long> {
}
