package com.sistema.canchas.service;

import com.sistema.canchas.model.PagoReserva;

public interface PagoReservaService extends GenericService<PagoReserva,Long>{
}
