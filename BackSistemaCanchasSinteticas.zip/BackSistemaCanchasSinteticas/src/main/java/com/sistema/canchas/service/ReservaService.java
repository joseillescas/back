package com.sistema.canchas.service;


import com.sistema.canchas.model.Reserva;

public interface ReservaService extends GenericService<Reserva,Long>{
    public Reserva obtenerUsuarioConPublicaciones(Long id);
}
