package com.sistema.canchas.service;

import com.sistema.canchas.model.Blacklist;

public interface BlacklistService extends GenericService<Blacklist,Long>{
}
