package com.sistema.canchas.repository;

import com.sistema.canchas.model.Reclamo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReclamoRepository extends JpaRepository<Reclamo,Long> {
}
